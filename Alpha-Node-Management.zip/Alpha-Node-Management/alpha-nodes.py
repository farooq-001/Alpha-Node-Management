import paramiko
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def gather_node_info(node):
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(node['hostname'], username=node['username'], password=node['password'])

        # Execute commands
        df_output = execute_command(ssh, "df -h")
        free_output = execute_command(ssh, "free -h")
        uptime_output = execute_command(ssh, "uptime")

        ssh.close()
        return {
            'df': df_output,
            'free': free_output,
            'uptime': uptime_output,
            'status': 'up'
        }
    except paramiko.AuthenticationException:
        return {
            'df': 'Error: Authentication Failed',
            'free': 'Error: Authentication Failed',
            'uptime': 'Error: Authentication Failed',
            'status': 'down'
        }
    except (paramiko.SSHException, TimeoutError):
        return {
            'df': 'Error: Connection Timeout',
            'free': 'Error: Connection Timeout',
            'uptime': 'Error: Connection Timeout',
            'status': 'down'
        }
    except Exception as e:
        return {
            'df': f'Error: {str(e)}',
            'free': f'Error: {str(e)}',
            'uptime': f'Error: {str(e)}',
            'status': 'down'
        }

def execute_command(ssh, command):
    stdin, stdout, stderr = ssh.exec_command(command)
    return stdout.read().decode('utf-8').strip()

@app.route('/')
def index():
    try:
        with open('nodes.conf') as f:
            nodes = [line.strip().split(',') for line in f.readlines()]
            nodes_conf = [{'hostname': node[1], 'username': node[2], 'password': node[3]} for node in nodes]

        results = {}
        for node in nodes_conf:
            info = gather_node_info(node)
            results[node['hostname']] = info
    except FileNotFoundError:
        return "Error: nodes.conf file not found."

    return render_template('index.html', results=results)

@app.route('/refresh-node/<node_name>', methods=['GET'])
def refresh_node(node_name):
    # Load nodes from the config file
    try:
        with open('nodes.conf') as f:
            nodes = [line.strip().split(',') for line in f.readlines()]
            nodes_conf = [{'hostname': node[1], 'username': node[2], 'password': node[3]} for node in nodes]
    except FileNotFoundError:
        return jsonify({'error': 'nodes.conf file not found'}), 404

    # Find the node by its hostname and refresh its data
    for node in nodes_conf:
        if node['hostname'] == node_name:
            info = gather_node_info(node)
            return jsonify(info)

    # If the node is not found, return an error response
    return jsonify({'error': f'Node {node_name} not found'}), 404

@app.route('/add_node', methods=['POST'])
def add_node():
    node_name = request.form['node_name']
    hostname = request.form['hostname']
    username = request.form['username']
    password = request.form['password']

    with open('nodes.conf', 'a') as f:
        f.write(f'{node_name},{hostname},{username},{password}\n')

    return jsonify({"status": "success"})

@app.route('/remove_node', methods=['POST'])
def remove_node():
    node_name = request.form['node_name']
    with open('nodes.conf', 'r') as f:
        lines = f.readlines()
    
    with open('nodes.conf', 'w') as f:
        for line in lines:
            if not line.startswith(f"{node_name},"):
                f.write(line)

    return jsonify({"status": "success"})

if __name__ == '__main__':
    app.run(debug=True)

